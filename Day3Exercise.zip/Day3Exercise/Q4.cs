﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise
{
    public interface ICar
    {
        void display(string CarName);
       
    }

 
    public class Car : ICar
    {
        
        public void display(string carName)
        {
            Console.WriteLine($"The price of {carName} is 377577");
        }
        

    }

    public class TestInterface
    {
        public static void Main()
        {
            Car c1 = new Car();
            c1.display("Maruti");
        }
    }
}
