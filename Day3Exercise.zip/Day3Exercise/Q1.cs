﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise
{
    struct Person
    {
        public string name;
        public string sex;
        public int height;
        public int weight;
        public void getValues(string nam, string gen, int ht, int wt)
        {
            name = nam;
            sex = gen;
            height = ht;
            weight = wt;
        }
        public void display()
        {
            Console.WriteLine($"name:{name}");
            Console.WriteLine($"sex:{sex}");
            Console.WriteLine($"height:{height}");
            Console.WriteLine($"weight:{weight}");
        }
    }


    public class TestStructure
    {
        public static void Main(string[] args)
        {
            Person P1 = new Person();
            P1.getValues("Samaira", "Female", 160, 55);
            P1.display();
        }
    }
}