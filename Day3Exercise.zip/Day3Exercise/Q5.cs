﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise
{
    class InvalidAgeException : Exception
    {
        public InvalidAgeException(string msg) : base(msg)
        {

        }
    }


    public class TestAge
    {
        public static void Main(string[] args)
        {

            Console.WriteLine("Enter your age:");
            int age = int.Parse(Console.ReadLine());
            try
            {
                if (age > 100)
                {
                    throw new InvalidAgeException("Please enter a valid age");
                }
                else
                    Console.WriteLine($"You are {age} years old.");
            }

            catch (InvalidAgeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
