﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise
{
    class Dimension
    {
        public double x;
        public double y;
        public virtual double area(double x,double y)
        {
            double area;
            area = x * y;
            return area;
        }
    }
    class Circle : Dimension
    {
        public override double area(double x, double y)
        {
            /// <summary>
            /// Calculates the area of a circle with radius x/y.
            /// </summary>
            double area;
            area = Math.PI * x * y;
            return area;
        }
    }
    class Sphere : Dimension
    {
        /// <summary>
        /// Calculates the area of a sphere with radius x/y.
        /// </summary>
        public override double area(double x, double y)
        {
            double area;
            area = 4 * Math.PI * x * y;
            return area;
        }
    }
    class Cylinder : Dimension
    {
        /// <summary>
        /// Calculates the area of a cylinder with height x and radius y.
        /// </summary>
       
        public override double area(double x, double y)
        {
            double area;
            area = 2 * Math.PI * x * y;
            return area;
        }
    }

    public class TestDim
    {

        public static void Main(string[] args)
        {
            Circle c = new Circle();
            Sphere s = new Sphere();
            Cylinder cy = new Cylinder();
            Console.WriteLine(c.area(4, 4));
            Console.WriteLine(s.area(4, 4));
            Console.WriteLine(cy.area(3,4));
        }
    }
}
