﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise
{
    class Details
    {
        int empid;
        string name;
        private string address;
        int pincode;
        private string phoneno;
        private int grossSalary;
        private int prf;
        private int netsal;


        public Details(int id, string nam, string add, int pc, string phno, int grossal, int pf)
        {
            empid = id;
            name = nam;
            address = add;
            pincode = pc;
            phoneno = phno;
            grossSalary = grossal;
            prf = pf;
            netsal = grossal - pf;
        }

        public int CalcSal(int grossal,int pf)
        {
            
            return netsal;
        }

        public string Grade(int grossal,int pf)
        {
            
            if (netsal>10000)
            {
                return "Grade-A";
            }
            else if(netsal >5000)
            {
                return "Grade-B";
            }
            else 
            {
                return "Grade-C";
            }
        }

    }
    public class TestSal
    {
        public static void Main(string[] args)
        {
            Details d = new(1234, "Veronica", "ABC Street",110082, "9876543210", 8000, 1800);
            Console.WriteLine(d.CalcSal(20000,1800));
            Console.WriteLine(d.Grade(20000,1800));
        }
    }
}
