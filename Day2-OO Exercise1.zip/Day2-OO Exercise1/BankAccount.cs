﻿using System;

/*QUESTION2- Create a class called BankAccount and have default constructor to take balance as 500 and another parameterized to take other than 500.
 */

public class BankAccount
{
    public int balance;

    
    public BankAccount()
    {
    balance = 500;
    }
    
    public BankAccount(int b)
    {
       balance = b;
    }
}


class TestBalance
{
    public static void Main()
    {
        BankAccount acc = new();
        Console.WriteLine(acc.balance);
        
    }
}

