﻿using System;

/*QUESTION3-Create a class called EmployeeSalary with attributes as EmployeeId, name, Basic salary, HR allowance, Travel Allowant, % of income tax deduction. 
 Provide appropriate visibility (private/public/protected/static)  of all the attributes. 
 Create a constructor to accept employee salary details.
*/

public class EmployeeSalary
{
    public int employeeID;
    public string name;
    public int basicSalary;
    private int hrAllowance;
    private int travelAllowance;
    private int incomeTaxDeduction;
    public EmployeeSalary(int sal)
    {
        basicSalary=sal;
    }

}

class TestSalary
{
    public static void Main()
    {
        EmployeeSalary sal = new(43663);
        Console.WriteLine(sal.basicSalary);
    }
}

