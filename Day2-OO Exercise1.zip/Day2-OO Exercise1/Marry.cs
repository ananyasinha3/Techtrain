﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_OO_Exercise1
{
    public class Person
    {
        public string name;
        private DateTime DOB;
        private string address;
        public string maritalStatus;
        public int age;

        public Person(string nam,DateTime dob,string add,string marStatus)
        {
            name = nam;
            DOB = dob;
            address = add;
            maritalStatus = marStatus;

        }
      
        public int GetAge() 
        {
            DateTime Today = DateTime.Today;
            age = Today.Year - DOB.Year;
            return age;
        }
        public bool CanMarry()
        {
            
            if (this.GetAge() > 18 && this.maritalStatus != "Married")
            {
                return true;
            }
            else
                return false;
        }
        public override string ToString()
        {
            string c;
            if (CanMarry() == true)
            {
                c = "can";
            }
                
            else
            {
                c = "cannot";
            }
                
            return $"{this.name} lives at {this.address}, born on {this.DOB.Date}, {this.GetAge()} years old and {c} marry.";
        }
    }
    class TestMarry
    {
        public static void Main()
        {
            Person p = new("Fred", new DateTime(1980,12,12), "21 Lancaster road", "Single");
            Console.WriteLine(p.GetAge());
            Console.WriteLine(p.CanMarry());
            Console.WriteLine(p.ToString());
        }
    }
}
