﻿using System;

/*QUESTION1- Circle is a class with property radius and methods setRadius(), getRadius(), calcDiameter(),calcArea(). 
 Use double precision for everything. 
 Write appropriate driver program to test the methods.
 */

public class Circle
{
    public double radius;

    public Circle()
    {
        radius = 0;
    }

    public Circle(double r)
    {
        radius = r;
    }

    public void setRadius(double r)
    {
        radius = r;
    }

    public double getRadius()
    {
        return radius;
    }

    public double calcDiameter()
    {
        return radius * 2;
    }

    public double calcArea()
    {
        return radius * radius *Math.PI;
    }

}

class TestCircle
{
    public static void Main()
    {
        Circle c = new(6);
        Console.WriteLine(c.getRadius());
        Console.WriteLine(c.calcDiameter());
        Console.WriteLine(c.calcArea());
    }
}