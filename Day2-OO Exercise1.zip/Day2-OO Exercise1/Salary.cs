﻿using System;

/*QUESTION3-Create a class called EmployeeSalary with attributes as EmployeeId, name, Basic salary, HR allowance, Travel Allowant, % of income tax deduction. 
 Provide appropriate visibility (private/public/protected/static)  of all the attributes. 
 Create a constructor to accept employee salary details.
*/

public class EmployeeSalary
{
    public int employeeID;
    public double name;
    public double basicSalary;
    private double hrAllowance;
    private double travelAllowance; 
    private double incomeTaxDeduction;
    public double gross;
    public EmployeeSalary(double basic, double hra, double travel, double tax)
    {
        basicSalary = basic;
        hrAllowance = hra;
        travelAllowance = travel;
        incomeTaxDeduction = tax;
        gross = (basic + hra + travel);
        basicSalary = gross - (gross * tax);
    }

}

class TestSalary
{
    public static void Main()
    {
        EmployeeSalary sal = new(20000, 16000, 2000, 0.2);
        Console.WriteLine(sal.basicSalary);
    }
}

