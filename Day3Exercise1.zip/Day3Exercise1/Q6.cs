﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class Freq
    {
        static int MaxFreq(int[] arr, int n)
        {
            Array.Sort(arr);
            int maxCount = 1;
            int count = 0;
            int num = 0;
            for (int i = 1; i < arr.Length; i++)
            {
                if (arr[i] == arr[i - 1])
                {
                    count++;
                }
                else
                {
                    if (count > maxCount)
                    {
                        maxCount = count;
                        num = arr[i - 1];
                    }
                    count = 1;
                }            
            }
            if(count>maxCount)
            {
                maxCount = count;
                num = arr[n - 1];
            }
            return num;
        }

        public static void Main()
        {
            int[] arr = { 3, 4, 4, 2, 3, 3, 4, 4, 4, 2, 2 };
            int n = arr.Length;
            Console.WriteLine(MaxFreq(arr, n));
        }
    }
}
