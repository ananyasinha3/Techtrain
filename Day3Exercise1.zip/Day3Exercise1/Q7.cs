﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class Repeat
    {
        static int Majorant(int[] arr, int n)
        {
    
            int counter = 0;
            int number = 0;
            int maxcount = 1;
            for (int i = 0; i < n; i++)
            {
                for (int j = i + 1; j < n; j++)
                {
                    if (arr[i] == arr[j])
                    {
                        counter++;
                    }
                    else if(counter>maxcount)
                    {
                        maxcount = counter;
                        number = arr[i];
                        counter = 1;
                    }
                }
                if (counter <=((n / 2) + 1))
                {
                    number = 0;
                }
                else
                {
                    number = arr[i];
                }
            }

            return number;



        }
           
    public static void Main()
    {
            int[] arr = { 2, 2, 3, 3, 2, 3, 4, 3, 2 };
        int n = arr.Length;
            int x = Majorant(arr, n);
            if(x==0)
            {
                Console.WriteLine("The majorant does not exist!");
            }
            else
            {
                Console.WriteLine(x);
            }

    }
}
}
