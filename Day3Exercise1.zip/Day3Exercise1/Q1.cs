﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class PositiveInt
    {
        public static List<int> ReadIntegers()
        {
            Console.WriteLine("Enter positive integers:");
            List<int> numSequence = new List<int>();
            string number = Console.ReadLine();
            while (number != string.Empty)
            {
                int numb;
                try
                {
                    numb = int.Parse(number);
                    if (numb < 0)
                    {
                        Console.WriteLine("Enter positive numbers");
                    }
                    else
                    {
                        numSequence.Add(numb);
                    }

                }
                catch (OverflowException e)
                {
                    Console.WriteLine(e.Message);
                }
                number = Console.ReadLine();
            }
            return numSequence;

        }
    }
    public class TestSum
    { 
        public static void Main()
        {
            List<int> numSequence = PositiveInt.ReadIntegers();
            Console.WriteLine($"Sum={numSequence.Sum()}");
            Console.WriteLine($"Average={numSequence.Average()}");
        }
    }
    
}
