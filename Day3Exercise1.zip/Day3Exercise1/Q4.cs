﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class RemNeg
    {
        public static void Main()
        {
            int[] arr = { 19, -10, 12, -6, -3, 34, -2, 5 };
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] <0)
                {


                }
            }
            
      
        }
    }
}
