﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class SortAsc:PositiveInt
    {
        public static void Main()
        {
            List<int> numSequence = ReadIntegers();
            numSequence.Sort();
            foreach (int n in numSequence)
            {
                Console.WriteLine(n);
            }
            
        }
    }
}
