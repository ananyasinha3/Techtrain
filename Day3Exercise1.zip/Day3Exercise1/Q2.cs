﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day3Exercise1
{
    class Reverse
    {
        public static Stack<int> ReadIntegers()
        {
            Console.WriteLine("Enter integers:");
            Stack<int> numSeq = new Stack<int>();
            
            string number = Console.ReadLine();
            while (number != string.Empty)
            {
                int numb;
                numb = int.Parse(number);
                numSeq.Push(numb);
                number = Console.ReadLine();
                
            }

            return numSeq;
        }
        public static void Main()
        {
            Stack<int> numSequence = Reverse.ReadIntegers();

            Console.WriteLine("Reverse: ");
            while (numSequence.Count != 0)
            {
                Console.WriteLine(numSequence.Pop());
            }

        }
    }

  
}
